from django.db import models
from .article_model import ArticleModel

class VehiculeModel(models.Model):
    model = models.CharField(max_length=100, blank=False, null=False)
    license_plate = models.CharField(max_length=12, blank=False, null=False)
    # articles = models.Many
    
    def __str__(self):
        return str(self.model) + " " + str(self.license_plate)