from rest_framework import serializers
from ..Models.vehicule_model import VehiculeModel

class VehiculeSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehiculeModel
        fields = "__all__"